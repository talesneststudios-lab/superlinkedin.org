const API_BASE = 'https://app.superlinkedin.org';
const SYNC_ALARM = 'superlinkedin-sync';

let pendingData = { followers: null, posts: [], profile: null, dashboardStats: null, dms: null, feedPosts: [] };

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'ANALYTICS_DATA') {
        mergeData(msg.payload);
        syncToServer();
    }

    if (msg.type === 'GET_STATUS') {
        chrome.storage.local.get(['authToken', 'lastSync', 'userName', 'plan'], (result) => {
            sendResponse({
                authenticated: !!result.authToken,
                lastSync: result.lastSync || null,
                userName: result.userName || null,
                plan: result.plan || 'Pro',
            });
        });
        return true;
    }

    if (msg.type === 'LOGIN') {
        login(msg.email, msg.linkedinId).then(sendResponse);
        return true;
    }

    if (msg.type === 'AUTO_LOGIN') {
        autoLoginViaCookie().then(sendResponse);
        return true;
    }

    if (msg.type === 'STORE_TOKEN') {
        storeTokenFromPage(msg.data).then(sendResponse);
        return true;
    }

    if (msg.type === 'LOGOUT') {
        chrome.storage.local.remove(['authToken', 'lastSync', 'userName', 'plan', 'ownerLinkedinId', 'ownerName']);
        sendResponse({ ok: true });
    }

    if (msg.type === 'FORCE_SYNC') {
        syncToServer().then(sendResponse);
        return true;
    }

    if (msg.type === 'GET_ANALYTICS') {
        getAnalyticsSummary().then(sendResponse);
        return true;
    }

    if (msg.type === 'DM_SEND_REPLY') {
        // Prefer a tab already on /messaging/ since the content script can
        // skip navigation. Fall back to any linkedin.com tab — the content
        // script will navigate to messaging itself. If neither exists, open
        // messaging in a background tab so future bulk sends just work.
        chrome.tabs.query({ url: '*://*.linkedin.com/*' }, (tabs) => {
            const messagingTab = tabs.find(t => /\/messaging(\/|$)/.test(t.url || ''));
            const liTab = messagingTab || tabs[0];
            const dispatch = (tabId) => {
                chrome.tabs.sendMessage(tabId, {
                    type: 'DM_SEND_REPLY',
                    recipientName: msg.recipientName,
                    text: msg.text,
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        sendResponse({ success: false, error: 'LinkedIn page not ready. Reload linkedin.com and try again.' });
                    } else {
                        sendResponse(response || { success: false, error: 'No response from LinkedIn page' });
                    }
                });
            };
            if (liTab) {
                dispatch(liTab.id);
            } else {
                chrome.tabs.create({ url: 'https://www.linkedin.com/messaging/', active: false }, (tab) => {
                    // Give the new tab a moment to boot the content script.
                    setTimeout(() => dispatch(tab.id), 6000);
                });
            }
        });
        return true;
    }
});

function mergeData(payload) {
    if (payload.followers !== undefined && payload.followers !== null) {
        pendingData.followers = payload.followers;
    }
    if (payload.profile) {
        pendingData.profile = payload.profile;
    }
    if (payload.posts && payload.posts.length > 0) {
        const existingTexts = new Set(pendingData.posts.map(p => p.text));
        payload.posts.forEach(p => {
            if (!existingTexts.has(p.text)) {
                pendingData.posts.push(p);
                existingTexts.add(p.text);
            }
        });
        if (pendingData.posts.length > 100) {
            pendingData.posts = pendingData.posts.slice(-100);
        }
    }
    if (payload.dashboardStats) {
        pendingData.dashboardStats = { ...(pendingData.dashboardStats || {}), ...payload.dashboardStats };
    }
    if (payload.dms) {
        pendingData.dms = payload.dms;
    }
    if (payload.feedPosts && payload.feedPosts.length > 0) {
        const existingTexts = new Set(pendingData.feedPosts.map(p => (p.text || '').substring(0, 80).toLowerCase()));
        payload.feedPosts.forEach(p => {
            const key = (p.text || '').substring(0, 80).toLowerCase();
            if (key && !existingTexts.has(key)) {
                pendingData.feedPosts.push(p);
                existingTexts.add(key);
            }
        });
        if (pendingData.feedPosts.length > 50) {
            pendingData.feedPosts = pendingData.feedPosts.slice(-50);
        }
    }
}

async function login(email, linkedinId) {
    try {
        const res = await fetch(`${API_BASE}/api/extension/auth`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, linkedinId }),
        });
        const data = await res.json();
        if (data.token) {
            await chrome.storage.local.set({
                authToken: data.token,
                userName: data.name || email,
                ownerLinkedinId: data.linkedinId || '',
                ownerName: data.name || '',
                plan: data.plan || 'Pro',
            });
            return { ok: true, name: data.name };
        }
        return { ok: false, error: data.error || 'Authentication failed' };
    } catch (err) {
        return { ok: false, error: 'Could not connect to server' };
    }
}

// Persist a token handed to us directly from a logged-in dashboard tab.
// This is the primary auto-connect path: the page does a same-origin fetch
// (cookie travels reliably) and forwards the resulting token to us.
async function storeTokenFromPage(data) {
    if (!data || !data.token) return { ok: false, error: 'No token' };
    await chrome.storage.local.set({
        authToken: data.token,
        userName: data.name || data.email || '',
        ownerLinkedinId: data.linkedinId || '',
        ownerName: data.name || '',
        plan: data.plan || 'Pro',
    });
    console.log('[SuperLinkedIn] Token stored from dashboard auto-login');
    return { ok: true, name: data.name };
}

// Cookie-based silent login (fallback). Works when the user is already
// signed into the SuperLinkedIn dashboard in the same browser profile.
// SameSite=Lax may prevent the session cookie from being sent on this
// cross-site fetch, in which case we fall through to the manual login flow
// or rely on the dashboard tab pushing us a token via STORE_TOKEN.
async function autoLoginViaCookie() {
    try {
        const res = await fetch(`${API_BASE}/api/extension/issue-token`, {
            method: 'GET',
            credentials: 'include',
            headers: { 'Accept': 'application/json' },
        });
        if (!res.ok) {
            return { ok: false, status: res.status, error: res.status === 401 ? 'Not signed in to SuperLinkedIn' : 'Auto-login failed' };
        }
        const data = await res.json();
        if (!data.token) return { ok: false, error: 'No token returned' };
        await chrome.storage.local.set({
            authToken: data.token,
            userName: data.name || data.email || '',
            ownerLinkedinId: data.linkedinId || '',
            ownerName: data.name || '',
            plan: data.plan || 'Pro',
        });
        return { ok: true, name: data.name, autoLogin: true };
    } catch (err) {
        return { ok: false, error: 'Could not connect to server' };
    }
}

async function syncToServer() {
    const { authToken } = await chrome.storage.local.get('authToken');
    if (!authToken) return { ok: false, error: 'Not authenticated' };

    const dataToSend = {
        followers: pendingData.followers,
        posts: pendingData.posts.slice(),
        profile: pendingData.profile,
        dashboardStats: pendingData.dashboardStats,
        dms: pendingData.dms,
        feedPosts: pendingData.feedPosts.slice(),
    };

    if (dataToSend.followers === null && dataToSend.posts.length === 0 && !dataToSend.dashboardStats && !dataToSend.dms && dataToSend.feedPosts.length === 0) {
        return { ok: true, message: 'Nothing to sync' };
    }

    try {
        const res = await fetch(`${API_BASE}/api/analytics/sync`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`,
            },
            body: JSON.stringify(dataToSend),
        });

        const result = await res.json();
        console.log('[SuperLinkedIn] Sync response:', res.status, JSON.stringify(result));

        if (res.ok) {
            pendingData = { followers: null, posts: [], profile: null, dashboardStats: null, dms: null, feedPosts: [] };
            const now = new Date().toISOString();
            await chrome.storage.local.set({ lastSync: now });
            return { ok: true, syncedAt: now };
        }

        if (res.status === 401) {
            await chrome.storage.local.remove(['authToken']);
            return { ok: false, error: 'Session expired. Please log in again.' };
        }

        return { ok: false, error: result.error || 'Sync failed' };
    } catch (err) {
        return { ok: false, error: 'Could not connect to server' };
    }
}

async function getAnalyticsSummary() {
    const { authToken } = await chrome.storage.local.get('authToken');
    if (!authToken) return { ok: false, error: 'Not authenticated' };

    try {
        const res = await fetch(`${API_BASE}/api/analytics/summary`, {
            headers: { 'Authorization': `Bearer ${authToken}` },
        });
        if (!res.ok) return { ok: false, error: 'Failed to fetch' };
        const data = await res.json();
        return { ok: true, data };
    } catch {
        return { ok: false, error: 'Could not connect to server' };
    }
}

chrome.alarms.create(SYNC_ALARM, { periodInMinutes: 15 });

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === SYNC_ALARM) {
        syncToServer();
    }
});
